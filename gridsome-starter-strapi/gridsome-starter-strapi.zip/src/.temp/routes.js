const c1 = () => import(/* webpackChunkName: "page--src-pages-register-vue" */ "C:\\Users\\Nazar\\Desktop\\project\\gridsome-starter-strapi\\src\\pages\\Register.vue")
const c2 = () => import(/* webpackChunkName: "page--src-pages-about-vue" */ "C:\\Users\\Nazar\\Desktop\\project\\gridsome-starter-strapi\\src\\pages\\About.vue")
const c3 = () => import(/* webpackChunkName: "page--node-modules-gridsome-app-pages-404-vue" */ "C:\\Users\\Nazar\\Desktop\\project\\gridsome-starter-strapi\\node_modules\\gridsome\\app\\pages\\404.vue")
const c4 = () => import(/* webpackChunkName: "page--src-pages-index-vue" */ "C:\\Users\\Nazar\\Desktop\\project\\gridsome-starter-strapi\\src\\pages\\Index.vue")

export default [
  {
    path: "/register/",
    component: c1
  },
  {
    path: "/about/",
    component: c2
  },
  {
    name: "404",
    path: "/404/",
    component: c3
  },
  {
    name: "home",
    path: "/",
    component: c4
  },
  {
    name: "*",
    path: "*",
    component: c3
  }
]
