export default {
  "trailingSlash": true,
  "pathPrefix": "",
  "titleTemplate": "%s - Gridsome",
  "siteUrl": "",
  "version": "0.7.19",
  "catchLinks": true
}